#!/usr/bin/env python3
"""
Chat Room Client (Version 2)
Name: David Douglass
Date: 2025 March 21
Description: A client application that connects to the chat server
and allows users to interact with the chat room through various commands.

Features:
- Login authentication
- New user creation
- Message broadcasting
- Private messaging
- User listing
- Logout handling
"""

import socket
import threading
import sys
import time

#configuration
HOST = '127.0.0.1'  #server IP
PORT = 18862  #server port 
BUFFER_SIZE = 1024

#flag to indicate if user is logged in
logged_in = False

def receive_messages(client_socket):
    """Function to continuously receive messages from the server."""
    global logged_in
    
    while True:
        try:
            message = client_socket.recv(BUFFER_SIZE).decode()
            if not message:
                break
            
            #enhanced protocol messages
            if message == "> LOGIN_SUCCESS":
                logged_in = True
                print("login confirmed")
            elif message == "> LOGIN_FAILED":
                print("login failed: invalid username or password")
            elif message == "> LOGOUT_SUCCESS":
                logged_in = False
                break
            elif message.startswith("> USER_CREATED"):
                print("user created successfully")
            elif message.startswith("> USER_EXISTS"):
                print("username already exists")
            else:
                #regular messages from server
                print(message)
            
        except Exception as e:
            print(f"Error receiving message: {e}")
            break

def validate_command(command_parts):
    """Validate command format and parameters."""
    if not command_parts:
        return False
        
    command = command_parts[0].lower()
    
    if command == "login":
        if not logged_in:
            if len(command_parts) != 3:
                print("> Usage: login UserID Password")
                return False
        else:
            print("> You are already logged in.")
            return False
    
    elif command == "newuser":
        if not logged_in:
            if len(command_parts) != 3:
                print("> Usage: newuser UserID Password")
                return False
            
            username = command_parts[1]
            password = command_parts[2]
            
            if len(username) < 3 or len(username) > 32:
                print("> Username must be between 3 and 32 characters.")
                return False
            
            if len(password) < 4 or len(password) > 8:
                print("> Password must be between 4 and 8 characters.")
                return False
        else:
            print("> Cannot create new user while logged in.")
            return False
    
    elif command == "send":
        if logged_in:
            if len(command_parts) < 3:
                print("> Usage: send all message OR send UserID message")
                return False
            
            recipient = command_parts[1]
            #join remaining parts as the message
            message = ' '.join(command_parts[2:])
            
            if len(message) < 1 or len(message) > 256:
                print("> Message must be between 1 and 256 characters.")
                return False
        else:
            print("> Denied. Please login first.")
            return False
    
    elif command == "who":
        if not logged_in:
            print("> Denied. Please login first.")
            return False
    
    elif command == "logout":
        if not logged_in:
            print("> You are not logged in.")
            return False
    
    else:
        print("> Invalid command.")
        return False
    
    return True

def send_command(client_socket, command):
    """Send a command to the server with error handling."""
    try:
        client_socket.send(command.encode())
        return True
    except Exception as e:
        print(f"> Error sending command: {e}")
        return False

def main():
    """Main function to start the client."""
    global logged_in
    
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    try:
        client_socket.connect((HOST, PORT))
        print("My chat room client. Version Two.")
        
        #start a thread to receive messages
        receive_thread = threading.Thread(target=receive_messages, args=(client_socket,))
        receive_thread.daemon = True
        receive_thread.start()
        
        while True:
            user_input = input("> ").strip()
            
            if not user_input:
                continue
            
            command_parts = user_input.split()
            
            if validate_command(command_parts):
                command = command_parts[0].lower()
                
                if command == "logout":
                    if send_command(client_socket, user_input):
                        #wait briefly to allow server response to arrive
                        time.sleep(0.5)
                        #logged_in = False;
                        break
                 
                else:
                    send_command(client_socket, user_input)
    
    except ConnectionRefusedError:
        print("Failed to connect to the server. Make sure the server is running.")
    except KeyboardInterrupt:
        print("\nDisconnecting from the server...")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        logged_in = False
        client_socket.close()

if __name__ == "__main__":
    main()