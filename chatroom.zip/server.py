#!/usr/bin/env python3
"""
Chat Room Server (Version 2)
Name: David Douglass
Date: 2025 March 21
Description: A multi-threaded chat server that handles multiple client connections
using socket API. The server manages user authentication, message broadcasting,
private messaging, and user management.

Features:
- Login authentication
- New user creation
- Message broadcasting
- Private messaging
- User listing
- Logout handling
"""

import socket
import threading
import os
import sys
import time

#configuration
HOST = '127.0.0.1'  # server IP
PORT = 18862 
MAX_CLIENTS = 3
BUFFER_SIZE = 1024
USER_FILE = 'users.txt'

#dictionary to store active connections: {username: (client_socket, client_address)}
active_clients = {}
#lock for thread-safe operations
clients_lock = threading.Lock()
file_lock = threading.Lock()

def initialize_user_file():
    """Initialize the users.txt file with default users if it doesn't exist."""
    if not os.path.exists(USER_FILE):
        with open(USER_FILE, 'w') as f:
            f.write("Tom,Tom11\n")
            f.write("David,David22\n")
            f.write("Beth,Beth33\n")
        print(f"Created {USER_FILE} with default users.")

def get_users():
    """Read users from the file and return as a dictionary."""
    users = {}
    try:
        with open(USER_FILE, 'r') as f:
            for line in f:
                if line.strip():
                    parts = line.strip().split(',')
                    if len(parts) >= 2:
                        username, password = parts[0], parts[1]
                        users[username] = password
    except FileNotFoundError:
        initialize_user_file()
        return get_users()
    except Exception as e:
        print(f"Error reading user file: {e}")
    return users

def save_user(username, password):
    """Save a new user to the file."""
    try:
        with file_lock:
            with open(USER_FILE, 'a') as f:
                f.write(f"{username},{password}\n")
        return True
    except Exception as e:
        print(f"Error saving user: {e}")
        return False

def send_to_client(client_socket, message):
    """Send a message to a client with error handling."""
    try:
        client_socket.send(message.encode())
        return True
    except Exception as e:
        print(f"Error sending message: {e}")
        return False

def broadcast_message(message, exclude=None):
    """Send a message to all connected clients except the excluded one."""
    with clients_lock:
        for username, (client_socket, _) in active_clients.items():
            if username != exclude:
                try:
                    send_to_client(client_socket, f"{message}")
                except Exception as e:
                    print(f"Error broadcasting to {username}: {e}")

def send_private_message(sender, recipient, message):
    """Send a private message to a specific client."""
    with clients_lock:
        if recipient in active_clients:
            try:
                recipient_socket = active_clients[recipient][0]
                return send_to_client(recipient_socket, f"{sender}: {message}")
            except Exception as e:
                print(f"Error sending private message: {e}")
                return False
        return False

def handle_client(client_socket, client_address):
    """Handle communication with a client."""
    username = None
    
    while True:
        try:
            data = client_socket.recv(BUFFER_SIZE).decode().strip()
            if not data:
                print(f"Empty data received from {client_address}, disconnecting.")
                break

            command_parts = data.split()
            if not command_parts:
                continue
                
            command = command_parts[0].lower()

            if not username:  #user is not logged in
                if command == "login" and len(command_parts) >= 3:
                    username_attempt = command_parts[1]
                    password_attempt = command_parts[2]
                    
                    users = get_users()
                    if username_attempt in users and users[username_attempt] == password_attempt:
                        with clients_lock:
                            if username_attempt in active_clients:
                                send_to_client(client_socket, "> LOGIN_FAILED")
                                print(f"Login attempt for already active user: {username_attempt}")
                                continue
                            #if there are already the max number of clients, don't let any more log in 
                            if len(active_clients) >= MAX_CLIENTS:
                                send_to_client(client_socket, "> Login denied. Maximum number of clients reached.")
                                break
                                
                            username = username_attempt
                            active_clients[username] = (client_socket, client_address)
                        
                        print(f"{username} login.")
                        send_to_client(client_socket, "> LOGIN_SUCCESS")
                        #notify other clients
                        broadcast_message(f"{username} joins.", username)
                    else:
                        send_to_client(client_socket, "> LOGIN_FAILED")
                        print(f"Failed login attempt for user: {username_attempt}")
                
                elif command == "newuser" and len(command_parts) >= 3:
                    new_username = command_parts[1]
                    new_password = command_parts[2]
                    
                    #validate username and password lengths
                    if len(new_username) < 3 or len(new_username) > 32:
                        send_to_client(client_socket, "Username must be between 3 and 32 characters.")
                        continue
                    
                    if len(new_password) < 4 or len(new_password) > 8:
                        send_to_client(client_socket, "Password must be between 4 and 8 characters.")
                        continue
                    
                    users = get_users()
                    if new_username in users:
                        send_to_client(client_socket, "> USER_EXISTS")
                    else:
                        if save_user(new_username, new_password):
                            send_to_client(client_socket, "> USER_CREATED")
                            print(f"New user created: {new_username}")
                        else:
                            send_to_client(client_socket, "Error creating user. Please try again.")
                
                else:
                    send_to_client(client_socket, "Denied. Please login first.")
            
            else:  #user is logged in
                if command == "send" and len(command_parts) >= 2:
                    if len(command_parts) < 3:
                        send_to_client(client_socket, "Usage: send all|UserID message")
                        continue
                        
                    recipient = command_parts[1]
                    #get message by joining all remaining parts
                    message = ' '.join(command_parts[2:])
                    
                    if len(message) < 1 or len(message) > 256:
                        send_to_client(client_socket, "Message must be between 1 and 256 characters.")
                        continue
                    
                    if recipient.lower() == "all":
                        print(f"{username}: {message}")
                        #broadcast to everyone except sender
                        broadcast_message(f"{username}: {message}", username)
                    else:
                        if recipient in active_clients:
                            print(f"{username} (to {recipient}): {message}")
                            send_private_message(username, recipient, message)
                        else:
                            send_to_client(client_socket, f"User {recipient} is not logged in.")
                
                elif command == "who":
                    with clients_lock:
                        if not active_clients:
                            send_to_client(client_socket, "No users are currently logged in.")
                        else:
                            user_list = ", ".join(sorted(active_clients.keys()))
                            send_to_client(client_socket, f"{user_list}")
                
                elif command == "logout":
                    send_to_client(client_socket, "> LOGOUT_SUCCESS")
                    broadcast_message(f"{username} left.", username)
                    #print(f"{username} logout.")
                    break
                else:
                    send_to_client(client_socket, "Invalid command.")
        
        except Exception as e:
            print(f"Error handling client {client_address}: {e}")
            break
    
    # Handle disconnection
    if username:
        with clients_lock:
            if username in active_clients:
                print(f"{username} logout.")
               
                del active_clients[username]
        
    
    try:
        client_socket.close()
    except:
        pass

def main():
    """Main function to start the server."""
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        server_socket.bind((HOST, PORT))
        server_socket.listen(MAX_CLIENTS)
        print("My chat room server. Version Two.")
        
        #init user file
        initialize_user_file()
        
        while True:
            client_socket, client_address = server_socket.accept()
            client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
            client_thread.daemon = True
            client_thread.start()
    
    except KeyboardInterrupt:
        print("\nShutting down the server...")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        with clients_lock:
            for username, (client_socket, _) in active_clients.items():
                try:
                    client_socket.close()
                except:
                    pass
        server_socket.close()
        print("Server shutdown complete.")

if __name__ == "__main__":
    main()